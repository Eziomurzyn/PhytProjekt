def parz(x):
    if(x%2==0):
        return True
    else:
        return False
    
def podziel_3(x):
    if(x%3==0):
        return True
    else:
        return False
    
    
def spr_war(f,tab):
    ls=[]
    for i in range(0,len(tab)):
        if(f(tab[i])):
            ls.append(tab[i])
    return ls

print(spr_war(podziel_3,[0,23,48,512,32,1,9,20]))
print(spr_war(parz,[0,23,48,512,32,1,9,20]))