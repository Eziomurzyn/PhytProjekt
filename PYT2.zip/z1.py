napis = input()

ls = [(slowo,len(slowo)) for slowo in napis.split()]

print(ls)