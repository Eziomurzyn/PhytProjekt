lista = [(0,2),(3,4),(7,2),(6,1)]
control_point = (0,0)

def odl(cp,lista):
    l=[]
    for i in lista:
        p=i
        k=((((cp[0]-p[0])**2 + (cp[1]-p[1])**2)**0.5),p)
        l.append(k)
    l.sort(key=lambda point:point[0])
    return l

print(odl(control_point,lista))