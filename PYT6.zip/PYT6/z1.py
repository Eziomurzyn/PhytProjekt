#! /usr/bin/env

def root(x):
    try:
        x**0.5
    except (ValueError,TypeError) as Ex:
        print(Ex)
    else:
        print(x**0.5)
        

root(4)
root(-4)
root('cztery')
