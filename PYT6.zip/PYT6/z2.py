#! /usr/bin/env

import re


class Wyjatek(Exception):
    pass


class Mail:
    def __init__(self, name):
        szablon = r"(^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$)"
        wynik = re.findall(szablon, name)
        if(len(wynik) != 1):
            try:
                raise Wyjatek("Zly adres")
            except Wyjatek as w:
                print(w)

object = Mail("jetluffy321@gmail.com")
