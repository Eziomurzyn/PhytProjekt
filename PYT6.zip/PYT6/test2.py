#! /usr/bin/env

class Wyjatek(Exception):
    pass

try:
    raise Wyjatek('Wystapil nieoczekiwany blad')
except Wyjatek as w:
    print (w)
    
        
