#! /usr/bin/env

def cdivide(x,y):
    try:
        result = x/y
    except (ZeroDivisionError,TypeError) as ex:
        print ('Wyjatek')
        print (ex)
    else:
        print('Brak wyjatku')
        return result
    finally:
        print('Koniec funkcji')
    
print (cdivide(4,0))
print (cdivide(4,'zero'))
print (cdivide(4,1))
        
