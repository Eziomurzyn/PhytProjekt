#! /usr/bin/env

import urllib2

response = urllib2.urlopen("https://www.reddit.com/")
file=open("strona.html","w")
file.write(response.read())

file.close()
