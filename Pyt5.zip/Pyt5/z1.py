#encoding: utf-8

import sys
import re

f=open(sys.argv[1])
width=int(sys.argv[2])
tekst=f.read()
w_arg=""
n=0
for i in range(0,width):
	w_arg+='.'
w_arg+='?'
for obj in re.findall(w_arg,tekst):
	print(obj)
	n+=1
if(width*n<len(tekst)):	
	print(tekst[width*n:])
f.close