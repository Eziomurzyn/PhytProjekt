#encoding: utf-8

import re
import sys

f=open(sys.argv[1])
tekst=f.read()

miesiac = {1 : 'Styczen',
           2 : 'Luty',
           3 : 'Marzec',
           4 : 'Kwiecien',
           5 : 'Maj',
           6 : 'Czerwiec',
           7 : 'Lipiec',
		   8 : 'Sierpien',
		   9 : 'Wrzesien',
		   10 : 'Pazdziernik',
		   11 : 'Listopad',
		   12 : 'Grudzien',
}

Pesel= '\d\d\d\d\d\d\d\d\d\d\d'
for match_object in re.findall(IP,tekst):
	rok=int(match_object[0])*10+int(match_object[1])_
	mies=int(match_object[2])*10+int(match_object[3]))
	dzien=int(match_object[4])*10+int(match_object[5]))
	if((match_object[9]%2==0):
		plec=kobieta
	else:
		plec=mezczyzna
	print(%d-%s-%d %s,dzien,miesiac[mies],rok,plec)
	