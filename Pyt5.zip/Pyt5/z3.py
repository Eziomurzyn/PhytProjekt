#encoding: utf-8

import re
import sys

f=open(sys.argv[1])
tekst=f.read()

IP= '\d\d\d\.\d\d\d.\d\d\d.\d\d\d'
IPList=[]
for match_object in re.findall(IP,tekst):
	IPList.append(match_object)

for i in IPList:
	Temp=[]
	Temp=i.split('.')
	if(int(Temp[0])<=255 and int(Temp[1])<=255 and int(Temp[2])<=255 and int(Temp[3])<=255):
		print(i)

f.close()

