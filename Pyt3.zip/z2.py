class Punkt2D:
    def __init__(self,x,y):
        self.coord=[]
        self.coord.append(x)
        self.coord.append(y)
    def distance(self,other):
        wynik=0
        for i in range (0,len(self.coord)):
            wynik+=(self.coord[i]-other.coord[i])**2
        wynik=wynik**0.5
        return wynik
            

class Punkt3D(Punkt2D):
    def __init__(self,Point,z):
        self.coord=Point.coord
        self.coord.append(z)
    def distance(self,other):
        return super(Punkt3D,self).distance(other)
        
        

a2=Punkt2D(10,5)
b2=Punkt2D(2,6)

print(a2.distance(b2))

a3=Punkt3D(a2,8)
b3=Punkt3D(b2,90)

print(a3.distance(b3))