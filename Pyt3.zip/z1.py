class Zespolona:
    def __init__(self,Re,Im):
        self.Re=Re
        self.Im=Im
    def __add__(self,other):
        wynik = Zespolona(self.Re+other.Re,self.Im+other.Im)
        return wynik
    def __sub__(self,other):
        wynik = Zespolona(self.Re-other.Re,self.Im-other.Im)
        return wynik
    def __mul__(self,other):
        wynik = Zespolona(self.Re*other.Re-self.Im*other.Im,self.Re*other.Im+self.Im*other.Re)
        return wynik
    def __truediv__(self,other):
        wynik = Zespolona((self.Re*other.Re+self.Im*other.Im)/(other.Re*other.Re+other.Im*other.Im),(self.Im*other.Re-self.Re*other.Im)/(other.Re*other.Re+other.Im*other.Im))
        return wynik
    def modul(self):
        return (self.Re*self.Re+self.Im*self.Im)**0.5
    def __str__(self):
        wynik = str(self.Re) + " + i" + str(self.Im)
        return wynik
    def __eq__(self,other):
        if(self.Re==other.Re and self.Im==other.Im):
            return True
        else:
            return False
    def __ne__(self,other):
        if(self.Re==other.Re and self.Im==other.Im):
            return False
        else:
            return True
    

A = Zespolona(6,4)
B = Zespolona(3,2)

print(A)
C=A+B
print(C)
C=A-B
print(C)
C=A*B
print(C)
C=A/B
print(C)