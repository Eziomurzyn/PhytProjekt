class Reflektor:
    __zarowka1 = None
    __zarowka2 = None
    def wlacz(self):
        self.__zarowka1=True
        self.__zarowka2=True
    def mignij(self):
        if(self.__zarowka1 and self.__zarowka2):
            print("*BLYSK*  *BLYSK*")
        else:
            print("Swiatla wylaczone")
    
class Silnik:
    __ile_benzyny = 0
    __przebieg = 10 #km/l
    def zatankuj(self,ile):
        self.__ile_benzyny=ile
    def odpal(self):
        print("Samochod pzejechal %d kilometrow" %(self.__ile_benzyny*self.__przebieg))
        
        
s=Silnik()
s.zatankuj(50)
s.odpal()