import pdb

def function():
	i = 0
	pdb.set_trace()
	while i<5:
		print i
		i+=1
a = "a"
pdb.set_trace()
b= "b"
function()
c= "c"
result = a + b + c
print result