import logging

def function():
	logging.info("Doing something")