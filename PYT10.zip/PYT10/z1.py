import Tkinter as tk
import tkFont as tkF
import logging

logging.basicConfig(filename='calc.log',level=logging.DEBUG)

root = tk.Tk()

default_font = tkF.nametofont("TkDefaultFont")
default_font.configure(size=20)
root.option_add("*Font",default_font)

stack=0;
operation=""

def upload(e,mark):
	global stack
	global operation
	stack=float(e.get())
	operation=mark
	logging.info("Pobranie liczby "+str(stack))
	e.delete(0,'end')

def finalize(e):
	global stack
	global operation
	n=float(e.get())
	logging.info("Operacja "+str(stack)+" "+str(operation)+" "+str(n))
	if(operation=='+'):
		stack+=n
		e.delete(0,'end')
		e.insert(tk.END,str(stack))
	if(operation=='-'):
		stack-=n
		e.delete(0,'end')
		e.insert(tk.END,str(stack))
	if(operation=='*'):
		stack*=n
		e.delete(0,'end')
		e.insert(tk.END,str(stack))
	if(operation=='/'):
		if(n==0):
			logging.debug("Dzielenie przez 0")
			clear(e)
		else:
			stack/=n
			e.delete(0,'end')
			e.insert(tk.END,str(stack))

def clear(e):
	global stack
	global operation
	logging.info("Operacja wyczyszczenia")
	e.delete(0,'end')
	stack=0
	operation=""



ent=tk.Entry(root)


plus_bt=tk.Button(text="+",command=lambda:upload(ent,"+"))
minus_bt=tk.Button(text="-",command=lambda:upload(ent,"-"))
multi_bt=tk.Button(text="*",command=lambda:upload(ent,"*"))
div_bt=tk.Button(text="/",command=lambda:upload(ent,"/"))
eq_bt=tk.Button(text="=",command=lambda:finalize(ent))
clear_bt=tk.Button(text="C",command=lambda:clear(ent))
ent.grid(column=0,row=0,columnspan=6)
plus_bt.grid(column=0,row=1)
minus_bt.grid(column=1,row=1,)
multi_bt.grid(column=2,row=1)
div_bt.grid(column=3,row=1)
eq_bt.grid(column=4,row=1)
clear_bt.grid(column=5,row=1)



root.mainloop()