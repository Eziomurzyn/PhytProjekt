import logging
import other

def main():
	logging.basicConfig(filename='app.log',level=logging.INFO)
	logging.info("Start")
	other.function()
	logging.warning("Warning")
	logging.debug("A problem occured")

if __name__ == "__main__":
	main()