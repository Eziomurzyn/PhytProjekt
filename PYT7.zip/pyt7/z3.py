#! /usr/bin/env python

from sqlalchemy import Column,Integer,String
from sqlalchemy.types import NUMERIC
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Ksiazki(Base):
    __tablename__ = 'Ksiazki'
    id = Column(Integer,primary_key=True)
    name = Column(String(100))
    price = Column(NUMERIC)
    
class Czytelnik(Base):
    __tablename__ = 'Czytelnik'
    id = Column(Integer,primary_key=True)
    name = Column(String(100))
    age = Column(Integer)
    
    

engine = create_engine('sqlite:///z1.db',echo=True)

Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()

for k in session.query(Ksiazki).all():
    print(k.id,k.name,k.price)
    
new_data = Czytelnik(
    id=0,
    name=u'Piotr',
    age=10
    )

session.add(new_data)

new_data = Czytelnik(
    id=1,
    name=u'Krzystof',
    age=15
    )
session.add(new_data)

for c in session.query(Czytelnik).all():
    print(c.id,c.name,c.age)
    

#session.commit()
