#! /usr/bin/env

import sqlite3
connection = sqlite3.connect('z1.db')
cursor = connection.cursor()

cursor.execute('''CREATE TABLE IF NOT EXISTS Ksiazki (id integer, name text, price real)''')

cursor.execute('''INSERT INTO Ksiazki VALUES (4,'Robinson Crusoe',8.6)''')
cursor.execute('''INSERT INTO Ksiazki VALUES (5,'Trzech Muszkieterow',22.95)''')
connection.commit()

for row in cursor.execute('''SELECT * FROM Ksiazki'''):
    print(row)
    
for row in cursor.execute('''SELECT name FROM Ksiazki WHERE price>20'''):
    print(row)

connection.rollback()

for row in cursor.execute('''SELECT name FROM Ksiazki WHERE price>20'''):
    print(row)

connection.close()
