#! /usr/bin/env python

from sqlalchemy import Column,Integer,String
from sqlalchemy.types import NUMERIC
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Ksiazki(Base):
    __tablename__ = 'Ksiazki'
    id = Column(Integer,primary_key=True)
    name = Column(String(100))
    price = Column(NUMERIC)
    
class Czytelnik(Base):
    __tablename__ = 'Czytelnik'
    id = Column(Integer,primary_key=True)
    name = Column(String(100))
    age = Column(Integer)
    
engine = create_engine('sqlite:///z1.db',echo=True)

Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()

for k in session.query(Ksiazki).filter(Ksiazki.price>15):
    print(k.id,k.name,k.price)
    
for k in session.query(Czytelnik).filter(Czytelnik.name=='Piotr'):
    print(k.id,k.name,k.age)

new_data = Czytelnik(
    id=2,
    name=u'Piotr',
    age=50
    )

session.add(new_data)    

for k in session.query(Czytelnik).filter(Czytelnik.name=='Piotr'):
    print(k.id,k.name,k.age)
    
session.rollback()

for k in session.query(Czytelnik).filter(Czytelnik.name=='Piotr'):
    print(k.id,k.name,k.age)

#session.commit()
