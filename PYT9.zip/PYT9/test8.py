import Tkinter as tk

root = tk.Tk()

cnv = tk.Canvas(root,width=200,height=100)
cnv.pack()
cnv.create_rectangle(50,20,150,80,fill="yellow")
cnv.create_rectangle(65,35,135,65,fill="#476042")
cnv.create_line(0,0,50,20,fill="blue",width=3)
cnv.create_line(0,100,50,80,fill="blue",width=3)
cnv.create_line(150,20,200,0,fill="blue",width=3)
cnv.create_line(150,80,250,120,fill="blue",width=3)

root.mainloop()