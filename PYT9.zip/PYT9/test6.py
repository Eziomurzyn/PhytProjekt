import Tkinter as tk
import tkFont as tkF
import tkMessageBox as tkMB

root = tk.Tk()

default_font = tkF.nametofont("TkDefaultFont")
default_font.configure(size=20)
root.option_add("*Font",default_font)

v = tk.IntVar()

def echo(val):
	print(val.get())

rb1=tk.Radiobutton(root,text="1",variable = v,value=1,command = lambda:echo(v))
rb2=tk.Radiobutton(root,text="2",variable = v,value=2,command = lambda:echo(v))
rb3=tk.Radiobutton(root,text="3",variable = v,value=3,command = lambda:echo(v))

rb1.grid(column=0,row=0)
rb2.grid(column=0,row=1)
rb3.grid(column=0,row=2)



root.mainloop()