import Tkinter as tk
import tkFont as tkF
import tkMessageBox as tkMB

root = tk.Tk()

default_font = tkF.nametofont("TkDefaultFont")
default_font.configure(size=20)
root.option_add("*Font",default_font)

scroll = tk.Scrollbar(root)
ta=tk.Text(root,height=10,width=50)
ta.pack(side=tk.LEFT,fill=tk.Y)
scroll.pack(side=tk.RIGHT,fill=tk.Y)
ta.config(yscrollcommand=scroll.set)
scroll.config(command=ta.yview)
ta.insert(tk.END,"Sample")
root.mainloop()