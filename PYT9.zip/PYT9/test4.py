import Tkinter as tk
import tkFont as tkF
import tkMessageBox as tkMB

root = tk.Tk()

default_font = tkF.nametofont("TkDefaultFont")
default_font.configure(size=48)
root.option_add("*Font",default_font)

state=0

def add(ent,val):
	global state
	state=int(ent.get())+val
	ent.delete(0,'end')
	ent.insert(tk.END,str(state))


e1 = tk.Entry(root)
e1.grid(row=0,column=0)

bt1 = tk.Button(root,text="1",command=lambda:add(e1,1))
bt1.grid(row=1,column=0)

bt2 = tk.Button(root,text="2",command=lambda:add(e1,2))
bt2.grid(row=1,column=1)

root.mainloop()