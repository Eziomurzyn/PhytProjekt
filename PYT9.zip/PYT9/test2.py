import Tkinter as tk
import tkFont as tkF

root = tk.Tk()

default_font = tkF.nametofont("TkDefaultFont")
default_font.configure(size=48)
root.option_add("*Font",default_font)

L1 = tk.Label(root,text="L1",bg="green")
L2 = tk.Label(root,text="L2",bg="red")
L3 = tk.Label(root,text="L3",bg="blue")

L1.grid(row=0,column=0,columnspan=2)
L2.grid(row=1,column=0)
L3.grid(row=1,column=1)

root.mainloop()