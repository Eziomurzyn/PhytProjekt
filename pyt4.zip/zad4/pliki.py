#encoding: utf-8

f = open("plik2.txt")
li=[]
for line in f:
	li.append(line)
print li
f.close()

with open("plik.txt","w") as f:
	f.write("test1")
	f.write("test2")