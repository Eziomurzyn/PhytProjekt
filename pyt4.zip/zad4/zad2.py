#encoding: utf-8

import sys
f= open(sys.argv[1])
slownik={}
for line in f:
	list=line.split(':')
	argument=list[1].split('\n')
	slownik[list[0]]=argument[0]
	
print slownik
f.close()