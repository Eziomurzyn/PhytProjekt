#encoding: utf-8

import sys
f = open(sys.argv[1])

napis=f.read()
list = napis.split()
slownik={}
for i in list:
	if(i!='\n'):
		slownik[i]=napis.count(i)

print slownik
f.close()