#encoding: utf-8

slownik = {
'kl':'wl',
'k2':'w2',
2:[1,2,3],
(4,3,2) : 4
}

slownik['nowy'] = 'dodany'

#print slownik.get(2)
#print slownik.get("brak")
#print slownik.get("k3","domyslna")

#for x in slownik.items():
	#print x
	
#for x in slownik.keys():
	#print x
	
#for x in slownik.values():
	#print x
	
lista = ["a","b","c","d"]
napis = "."
print napis.join(lista)

napis2 = "Ala ma kota"
print napis2.split()
napis3 = "Kot.ma.ale"
print napis3.split('.')