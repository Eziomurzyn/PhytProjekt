#encoding: utf-8

napis = """k1:w1
k2:w2
k3:w3
k4:w4"""
li1=napis.split('\n')
li2=[]
slownik={}
for i in li1:
	li2.append(i.split(':'))
for i in li2:
	slownik[i[0]]=i[1]

print slownik