#encoding: utf-8

import sys

if(sys.argv[1]!="-"):
	with open(sys.argv[1],"r") as f:
		tekst = f.split('\n')
		for i in tekst:
			if(i.find(sys.argv[2]!= -1)):
				print i
else:
	list=[]
	stop=False
	while(stop==False):
		l=raw_input()
		if(l==""):
			stop=True
		else:
			list.append(l)
	for i in list:
			if(i.find(sys.argv[2]!= -1)):
				print i
