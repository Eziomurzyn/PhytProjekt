#encoding: utf-8

import sys

with open(sys.argv[1],"r") as f:
	napis = f.read()
	for i in range(0,length(napis))
		if(napis[i]!=' ' and napis[i]!='\n'):
			napis[i]+=sys.argv[3]

with open(sys.argv[2],"w") as f:
	f.write(napis)